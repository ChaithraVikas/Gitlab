package com.gitlab.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.gitlab.qa.base.TestBase;

public class RegistrationPage extends TestBase{
	
	@FindBy(xpath="//*[@id=\"main-nav\"]/div[2]/ul/div[2]/li[3]/a")
	WebElement register_link;
	
	@FindBy(id="new_user_first_name")
	WebElement first_name;
	
	@FindBy(id="new_user_last_name")
	WebElement last_name;
	
	@FindBy(id="new_user_username")
	WebElement username;
	
	@FindBy(id="new_user_email")
	WebElement email_id;
	
	@FindBy(id="new_user_password")
	WebElement password;
	
	@FindBy(id="new_user_email_opted_in")
	WebElement email_opted_in;
	
	@FindBy(xpath="//input[@type='submit' and @value='Register']")
	WebElement register_btn;
	
	public RegistrationPage(){
		PageFactory.initElements(driver, this);
	}
	
	public void register(String fname,String lname,String uname,String email,String pwd )
	{
		first_name.sendKeys(fname);
		last_name.sendKeys(lname);
		username.sendKeys(uname);
		email_id.sendKeys(email);
		password.sendKeys(pwd);
		email_opted_in.click();
		
		
	}
	
	
	
	

}
