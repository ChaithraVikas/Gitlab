package com.gitlab.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.gitlab.qa.base.TestBase;

public class HomePage extends TestBase{
	@FindBy(xpath="//a[@class='btn btn-success' and contains(text(),'New project')]")
	WebElement new_project;
	
	public HomePage(){
		PageFactory.initElements(driver, this);
	}
	
	
	  public String verifyHomepageTitle() { String t= driver.getTitle();
	  System.out.println(t); return t; }
	 
	
	public NewProjectPage clickOnNewProject()
	{
		new_project.click();
		return new NewProjectPage();
	}
}
