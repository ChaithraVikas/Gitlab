package com.gitlab.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.gitlab.qa.base.TestBase;

public class LoginPage extends TestBase {
	@FindBy(id="user_login")
	WebElement username;
	
	@FindBy(id="user_password")
	WebElement password;
	
	@FindBy(xpath="//input[@type='submit' and @value='Sign in']")
	WebElement login_btn;
	
	public LoginPage(){
		PageFactory.initElements(driver, this);
	}
	
	public String validatePageTitle() {
		return driver.getTitle();
		
	}

	
	/*
	 * public void signIn() { Sign_in_link.click();
	 * driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_WAIT,
	 * TimeUnit.SECONDS); }
	 */
	public HomePage login(String un, String pswd) {
		
		username.sendKeys(un);
		password.sendKeys(pswd);
		login_btn.click();
		
		return new HomePage();
	}
}
