package com.gitlab.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.gitlab.qa.base.TestBase;

public class NewProjectPage extends TestBase {

		
	/*
	 * @FindBy(xpath="//*[@id=\"content-body\"]/div[2]/div[2]/div[2]/a[1]")
	 * WebElement create_blank_project;
	 * 
	 * 
	 * public NewProjectPage(){ PageFactory.initElements(driver, this); }
	 * 
	 * public BlankProject clickoncreateproject() { create_blank_project.click();
	 * return new BlankProject(); }
	 */
}
