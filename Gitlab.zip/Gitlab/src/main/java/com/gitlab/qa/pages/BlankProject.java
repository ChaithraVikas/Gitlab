package com.gitlab.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.gitlab.qa.base.TestBase;

public class BlankProject extends TestBase{

	@FindBy(id="project_path")
	WebElement project_slug;
	
	@FindBy(xpath="//*[@id=\"new_project\"]/input[3]")
	WebElement create_project_btn;
	
	public BlankProject(){
		PageFactory.initElements(driver, this);
	}
	
	public void createProject(String proj_slug) {
		project_slug.sendKeys(proj_slug);
		
		create_project_btn.click();
		
	}
}
