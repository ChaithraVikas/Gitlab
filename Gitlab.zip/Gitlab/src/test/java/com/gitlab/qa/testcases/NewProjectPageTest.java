package com.gitlab.qa.testcases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.gitlab.qa.base.TestBase;
import com.gitlab.qa.pages.BlankProject;
import com.gitlab.qa.pages.HomePage;
import com.gitlab.qa.pages.LoginPage;
import com.gitlab.qa.pages.NewProjectPage;

public class NewProjectPageTest extends TestBase{
	LoginPage loginpage;
	HomePage homepage;
	NewProjectPage newprojectpage;
	BlankProject blankProject;
	
	@BeforeMethod
	public void setup() {
		initialization();
		loginpage=new LoginPage();
		homepage=loginpage.login(prop.getProperty("username"), prop.getProperty("password"));
		newprojectpage=homepage.clickOnNewProject();
		blankProject= new BlankProject();
		
	}
	
	/*
	 * @Test public void clickoncreateprojectTest() {
	 * blankProject=newprojectpage.clickoncreateproject(); }
	 */
	
	@AfterMethod
	public void teardown()
	{
		driver.quit();
	
	}
}
