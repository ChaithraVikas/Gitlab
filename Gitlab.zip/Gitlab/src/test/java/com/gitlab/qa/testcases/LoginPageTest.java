package com.gitlab.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.gitlab.qa.base.TestBase;
import com.gitlab.qa.pages.HomePage;
import com.gitlab.qa.pages.LoginPage;
import com.gitlab.qa.util.TestUtil;

public class LoginPageTest extends TestBase{
	
	LoginPage loginpage;
	HomePage homepage;
	
	String sheetName="login";
	
	public LoginPageTest() {
		super();
	}
	
	@BeforeMethod
	public void setup() {
		initialization();
		loginpage=new LoginPage();
	}
	
	@Test(priority=1)
	public void loginPageTitleTest()
	{
		String title=loginpage.validatePageTitle();
		Assert.assertEquals(title, "Checking your Browser - GitLab");
	}
	
	
	
	  @DataProvider 
	  public Object[][] getgitlabTestData(){ 
		  Object data[][] =TestUtil.getTestData(sheetName); 
		  return data; 
		  }
	  
	  
	  @Test(priority=2, dataProvider="getgitlabTestData") 
	  public void loginTest(String username,String password) {
	  
	  homepage=loginpage.login(username,password); }
	 
	
	/*
	 * @Test(priority=2) public void loginTest() {
	 * homepage=loginpage.login(prop.getProperty("username"),
	 * prop.getProperty("password")); }
	 */
	 
	@AfterMethod
	public void tearDown()
	{
		driver.quit();
	}

}
