package com.gitlab.qa.testcases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.gitlab.qa.base.TestBase;
import com.gitlab.qa.pages.BlankProject;
import com.gitlab.qa.pages.HomePage;
import com.gitlab.qa.pages.LoginPage;
import com.gitlab.qa.pages.NewProjectPage;
import com.gitlab.qa.util.TestUtil;

public class BlankProjectTest extends TestBase{
	
	LoginPage loginpage;
	HomePage homepage;
	NewProjectPage newprojectpage;
	BlankProject blankProject;
	String sheetName="project";
	
	@BeforeMethod
	public void setup() {
		initialization();
		loginpage=new LoginPage();
		homepage=loginpage.login(prop.getProperty("username"), prop.getProperty("password"));
		newprojectpage=homepage.clickOnNewProject();
		//blankProject= newprojectpage.clickoncreateproject();
		
	}
	@DataProvider 
	public Object[][] getgitlabData(){ 
		Object data[][]=TestUtil.getTestData(sheetName);
		return data; 
		}
	@Test(dataProvider="getgitlabData")
	public void createProjectTest(String projectslug) {
		blankProject.createProject(projectslug);
		
	}
	
	@AfterMethod
	public void tearDown()
	{
		driver.quit();
	}

}
