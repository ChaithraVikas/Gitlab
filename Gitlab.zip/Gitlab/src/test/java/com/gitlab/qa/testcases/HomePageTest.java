package com.gitlab.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.gitlab.qa.base.TestBase;
import com.gitlab.qa.pages.HomePage;
import com.gitlab.qa.pages.LoginPage;
import com.gitlab.qa.pages.NewProjectPage;

public class HomePageTest extends TestBase{
	
	LoginPage loginpage;
	HomePage homepage;
	NewProjectPage newprojectpage;
	
	public HomePageTest() {
		super();
	}


	@BeforeMethod
	public void setup() {
		initialization();
		loginpage=new LoginPage();
		//testUtil = new TestUtil();
		
		 homepage=loginpage.login(prop.getProperty("username"), prop.getProperty("password"));
		newprojectpage= new NewProjectPage();
	}
	
	  @Test(priority=1) public void verifyHomePageTitleTest() { String
	  homepagetitle=homepage.verifyHomepageTitle();
	  Assert.assertEquals(homepagetitle, "Projects � Dashboard � GitLab"); }
	 
	  
	  @Test
	  public void clickOnNewProjectTest() {
	  newprojectpage=homepage.clickOnNewProject(); 
	  }
	 
	@AfterMethod
	public void tearDown()
	{
		driver.quit();
	}

}
