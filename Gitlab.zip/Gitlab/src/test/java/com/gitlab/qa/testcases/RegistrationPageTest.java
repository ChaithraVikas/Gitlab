package com.gitlab.qa.testcases;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.gitlab.qa.base.TestBase;
import com.gitlab.qa.pages.RegistrationPage;
import com.gitlab.qa.util.TestUtil;

public class RegistrationPageTest extends TestBase{
	
	RegistrationPage registrationpage;
	String sheetName="register";
	
	public RegistrationPageTest() {
		super();
	}
	
	@BeforeMethod
	public void setup() {
		initialization();
		registrationpage=new RegistrationPage();
	}
	
	
	
	  @DataProvider 
	  public Object[][] getgitlabData(){ 
		  Object data[][] =TestUtil.getTestData(sheetName); 
		  return data; 
		  }
	  
	  
	  @Test(dataProvider="getgitlabData") 
	  public void registerTest(String fname,String lname,String uname,String email,String pwd )
	  {
		  registrationpage.register(fname,lname,uname,email,pwd);
	  }
	 
	 
	@AfterMethod
	public void tearDown()
	{
		driver.quit();
	}

}
